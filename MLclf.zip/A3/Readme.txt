The code is mainly divided into three data processing modules, each module is implemented with a different classifier, 
and returns the accuracy rate

Module one count（random forest, logical regression,NB,KNN,MLP）
Module two tfidf（random forest, logical regression,NB,KNN,MLP）
Module three glove300(logical regression,NB,KNN)

In the second module, the csv file is exported as the test prediction dataset result. 
The accuracy rate, F1 score and CV score are used in the model evaluation process